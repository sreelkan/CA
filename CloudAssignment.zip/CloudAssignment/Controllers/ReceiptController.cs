﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using System.Web;
using System.Web.ModelBinding;
using System.Web.Mvc;
using CloudAssignment.Models;
using Microsoft.Build.Tasks.Deployment.Bootstrapper;

namespace CloudAssignment.Controllers
{
    public class ReceiptController : Controller
    {
        // GET: Receipt
        Training_12DecMumbaiEntities5 db = new Training_12DecMumbaiEntities5();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddReceipt()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddReceipt(HttpPostedFileBase file, FormCollection form)
        {
            Receipt newRecord = new Receipt();
            newRecord.ReceiptNumber = Convert.ToInt32(form["ReceiptNumber"]);
            newRecord.ReceiptDate = DateTime.Parse(form["ReceiptDate"]);
            newRecord.EmployeeId = Convert.ToInt32(form["EmployeeId"]);
            newRecord.ReceiptAmount = Convert.ToInt32(form["ReceiptAmount"]);
           
            if (file != null)
            {
                string ImageName = System.IO.Path.GetFileName(file.FileName);
                string physicalPath = Path.Combine(Server.MapPath("~/Image/" + ImageName)); 

                // save image in folder
                file.SaveAs(physicalPath);

                //save new record in database
                
                //newRecord.ReceiptNumber = Convert.ToInt32(Request.Form["ReceiptNumber"]);
                //newRecord.ReceiptDate = DateTime.Parse(Request.Form["ReceiptDate"]);
                //newRecord.EmployeeId= Convert.ToInt32(Request.Form["EmployeeId"]);
                newRecord.ReceiptUrl = ImageName;
                //newRecord.Category = Request.Form["Category"];
                //newRecord.ReceiptAmount = Convert.ToInt32(Request.Form["ReceiptAmount"]);
                db.Receipts.Add(newRecord);
                Session["userStudent"] = newRecord;
                db.SaveChanges();

            }
            //Display records
            return RedirectToAction("ViewReceipts");
        }

        public ActionResult ViewReceipts()
        {
            Receipt student = (Receipt)Session["userStudent"];
            //Session["userStudent"] = student;

            return View(student);

            }

        //[HttpPost]
        //public ActionResult ViewReceipts(FormCollection fc)
        //{

        //    Re stu = (Student)Session["userStudent"];
        //    Session["userStudent"] = student;
        //    Receipt receipt = new Receipt();
        //    receipt.ReceiptNumber = Convert.ToInt32(fc["ReceiptNumber"]);
        //    receipt.ReceiptAmount = Convert.ToInt32(fc["ReceiptAmount"]);
        //    receipt.ReceiptDate = DateTime.Parse(fc["ReceiptDate"]);
        //    receipt.Status = fc["Status"];

        //    return View();
        //}
    }
}