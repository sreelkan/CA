﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CloudAssignment.Models;
using Microsoft.Build.Tasks.Deployment.Bootstrapper;
using static CloudAssignment.Models.Receipt;

namespace CloudAssignment.Controllers
{
    public class SupervisorController : Controller
    {
        Training_12DecMumbaiEntities5 db = new Training_12DecMumbaiEntities5();
        // GET: Supervisor
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ReceiptDetails()
        {
            return View();
        }
        public ActionResult ReceiptDetails(int id)
        {
            //var product = db.MapSupervisorEmps.Where(p => p.SupervisorId == id).FirstOrDefault();
            //// note you may need to add .Include("SpecificationsTable") in the above
            //if (product == null)
            //{
            //    return new HttpNotFoundResult();
            //}
            //Supervisor model = new Supervisor()
            //{
            //    EmployeeId = product.EmployeeId,
            //    SupervisorId= product.SupervisorId
            //    Specifications = product.SpecificationsTable.Select(s => new SpecificationVM()
            //    {
            //        Name = s.SpecificationName,
            //        Value = s.SpecificationValue
            //    })
            //};


            //    List<Employee> employees = db.Employees.ToList();
            //    List<MapSupervisorEmp> mapSupervisorEmp = db.MapSupervisorEmps.ToList();
            //    List<Receipt> receipts = db.Receipts.ToList();

            ////var employeeRecord = from e in employees
            ////                     join d in receipts on e.EmployeeId equals d.EmployeeId into table1
            ////                     from d in table1.ToList()
            ////                     //join i in mapSupervisorEmp on e.EmployeeId equals i.IncentiveId into table2
            ////                     //from i in table2.ToList()
            ////                     select new ViewModel
            ////                     {
            ////                         employee = e,
            ////                         //mapSupervisorEmp = i,
            ////                         incentive = d
            ////                     };
            //var query = from e in Employee
            //            join d in Receipt on e.deptno equals d.deptno
            //            select new { e.deptno, d.deptno };

            //public Product> FindAllProducts()
            //{
            //    return from n in db.Products
            //           join c in db.Categories on n.CategoryId equals c.CategoryId
            //           orderby n.ProductId descending
            //           select new { n.ProductName, n.ProductId, c.CategoryId, c.CategoryName };
            //}

            return View();
            }

            //return View();
        }
    }
