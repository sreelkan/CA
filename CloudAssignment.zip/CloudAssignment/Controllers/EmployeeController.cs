﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CloudAssignment.Models;

namespace CloudAssignment.Controllers
{
    public class EmployeeController : Controller
    {
        Training_12DecMumbaiEntities5 db = new Training_12DecMumbaiEntities5();
        // GET: Employee
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult EmployeeHome()
        {

            return View();

        }
        [HttpPost]
        public ActionResult EmployeeHome(FormCollection fc)
        {
            Employee employee = new Employee();

            string value = fc["submit"];
            int a = Convert.ToInt32(fc["EmployeeId"]);
            
            //employee = db.Employees.Find(a);
            switch(value)
            {
                case "Details":
                    return Redirect("EmployeeDetails/" + a); //(EmployeeDetails(a));
                case "Edit":
                    return Redirect("EmployeeEdit/" + a); //(EmployeeDetails(a));
                    //return (EmployeeEdit(a));

            }


            return View();

        }
        public ActionResult EmployeeEdit(int? id)
        {
            TempData["EmpId"] = id;
            TempData.Keep();
            
            Employee employee = db.Employees.Find(id);
            return View(employee);

        }
        [HttpPost]
        public ActionResult EmployeeEdit(FormCollection fc)
        {

            Employee employee = new Employee();
            employee.EmployeeId = Convert.ToInt32(TempData["EmpId"]);
            employee.Name = fc["Name"];
            employee.DateOfJoining = DateTime.Parse(fc["DateOfJoining"]);
            employee.Location = fc["Location"];
            employee.Department = fc["Department"];
            employee.Experience = Convert.ToInt32(fc["Experience"]);
            employee.Role = fc["Role"];
            db.Entry(employee).State = EntityState.Modified;
            db.SaveChanges();

            return RedirectToAction("EmployeeDetails", new { id = employee.EmployeeId });

        }


        


        public ActionResult EmployeeDetails(int? id)
        {
            Employee employee = db.Employees.Find(id);
            return View(employee);

        }
    }
}